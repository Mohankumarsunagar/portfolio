
import rsa

(public_key, private_key) = rsa.newkeys(512)

def rsa_encrypt(text):
    return rsa.encrypt(text.encode(), public_key)

def rsa_decrypt(cipher):
    return rsa.decrypt(cipher, private_key).decode()

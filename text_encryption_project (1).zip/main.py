
from aes_module import aes_encrypt, aes_decrypt
from des_module import des_encrypt, des_decrypt
from rsa_module import rsa_encrypt, rsa_decrypt
import base64

def menu():
    print("\n=== Text Encryption Tool ===")
    print("1. AES Encryption")
    print("2. DES Encryption")
    print("3. RSA Encryption")
    print("0. Exit")

while True:
    menu()
    choice = input("Choose an option: ")

    if choice == '1':
        text = input("Enter text: ")
        key = input("Enter 16-char key: ")
        encrypted = aes_encrypt(text, key)
        print("Encrypted:", encrypted)
        print("Decrypted:", aes_decrypt(encrypted, key))

    elif choice == '2':
        text = input("Enter text: ")
        key = input("Enter 8-char key: ")
        encrypted = des_encrypt(text, key)
        print("Encrypted:", encrypted)
        print("Decrypted:", des_decrypt(encrypted, key))

    elif choice == '3':
        text = input("Enter text: ")
        encrypted = rsa_encrypt(text)
        print("Encrypted (base64):", base64.b64encode(encrypted).decode())
        print("Decrypted:", rsa_decrypt(encrypted))

    elif choice == '0':
        break

    else:
        print("Invalid choice.")

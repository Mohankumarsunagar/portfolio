
from Crypto.Cipher import DES
from Crypto.Util.Padding import pad, unpad
import base64

def des_encrypt(text, key):
    key = key.ljust(8)[:8].encode()
    cipher = DES.new(key, DES.MODE_ECB)
    encrypted = cipher.encrypt(pad(text.encode(), 8))
    return base64.b64encode(encrypted).decode()

def des_decrypt(encrypted_text, key):
    key = key.ljust(8)[:8].encode()
    cipher = DES.new(key, DES.MODE_ECB)
    decrypted = unpad(cipher.decrypt(base64.b64decode(encrypted_text)), 8)
    return decrypted.decode()
